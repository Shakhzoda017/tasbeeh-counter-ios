import UIKit

enum DhikrType: String, CaseIterable {
    case subhanAllah = "SubhanAllah"
    case alhamdulillah = "Alhamdulillah"
    case allahuAkbar = "Allahu Akbar"
}

class TasbeehCounter {
    private var count: Int = 0
    private var dhikrType: DhikrType = .subhanAllah

    func increment() {
        if count < 100 {
            count += 1
        }
    }

    func reset() {
        count = 0
    }

    func getCount() -> Int {
        return count
    }

    func setDhikrType(_ type: DhikrType) {
        dhikrType = type
    }

    func getCurrentDhikrType() -> DhikrType {
        return dhikrType
    }
}

class ViewController: UIViewController {

    
    @IBOutlet weak var countLabel: UILabel!
    @IBOutlet weak var dhikrTypeLabel: UILabel!
    @IBOutlet weak var countButton: UIButton!
    @IBOutlet weak var resetButton: UIButton!
    @IBOutlet weak var dhikrSegmentedControl: UISegmentedControl!

    private let tasbeehCounter = TasbeehCounter()
    private let dhikrTypes: [DhikrType] = DhikrType.allCases

    override func viewDidLoad() {
        super.viewDidLoad()


        dhikrSegmentedControl.removeAllSegments()
        for (index, type) in dhikrTypes.enumerated() {
            dhikrSegmentedControl.insertSegment(withTitle: type.rawValue, at: index, animated: false)
        }
        dhikrSegmentedControl.selectedSegmentIndex = 0

        updateDisplay()
    }

 
    @IBAction func countButtonTapped(_ sender: UIButton) {
        tasbeehCounter.increment()
        updateDisplay()
    }

    @IBAction func resetButtonTapped(_ sender: UIButton) {
        let alert = UIAlertController(title: "Reset Counter", message: "Reset to 0?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Reset", style: .destructive, handler: { _ in
            self.tasbeehCounter.reset()
            self.updateDisplay()
        }))
        present(alert, animated: true)
    }

    @IBAction func dhikrTypeChanged(_ sender: UISegmentedControl) {
        let selectedIndex = sender.selectedSegmentIndex
        let selectedType = dhikrTypes[selectedIndex]

        tasbeehCounter.reset()
        tasbeehCounter.setDhikrType(selectedType)
        updateDisplay()
    }

  
    private func updateDisplay() {
        let count = tasbeehCounter.getCount()
        let currentType = tasbeehCounter.getCurrentDhikrType()

        countLabel.text = "\(count)"
        dhikrTypeLabel.text = currentType.rawValue
    }
}
